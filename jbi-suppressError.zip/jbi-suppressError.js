define( ["qlik"],
	function (qlik) {
	var app=qlik.currApp(app),field,selected;
	return {
		initialProperties: {},
		definition: {},
		paint : function($element, layout) {
		qlik.on( "error", function ( msg ) {
				console.log(msg);
			} );
			qlik.on( "warning", function ( msg ) {
				console.log(msg);
			} );
			qlik.on( "closed", function ( msg ) {
				console.log(msg);
			} );
		}
	};
} );